<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

$dataDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data';
$dataFile = $dataDir . DIRECTORY_SEPARATOR . 'projects.json';

if (!is_dir($dataDir)) {
    mkdir($dataDir, 0775, true);
}

if (!file_exists($dataFile)) {
    file_put_contents($dataFile, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
}

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES);
    exit;
}

function readProjects(string $path): array
{
    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function writeProjects(string $path, array $projects): bool
{
    $fp = @fopen($path, 'c+');
    if (!$fp) {
        return false;
    }

    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        return false;
    }

    $encoded = json_encode(array_values($projects), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) {
        flock($fp, LOCK_UN);
        fclose($fp);
        return false;
    }

    ftruncate($fp, 0);
    rewind($fp);
    $ok = fwrite($fp, $encoded) !== false;
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    return $ok;
}

function sanitizeString(mixed $value, int $maxLength = 400): string
{
    $text = trim((string)$value);
    $text = strip_tags($text);
    if (mb_strlen($text) > $maxLength) {
        $text = mb_substr($text, 0, $maxLength);
    }
    return $text;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    respond(200, ['projects' => readProjects($dataFile)]);
}

if ($method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) {
        respond(400, ['error' => 'Invalid JSON payload.']);
    }

    $name = sanitizeString($body['name'] ?? '', 120);
    $category = sanitizeString($body['category'] ?? '', 80);
    $description = sanitizeString($body['description'] ?? '', 600);
    $link = sanitizeString($body['link'] ?? '', 500);
    $status = sanitizeString($body['status'] ?? 'pending', 16);
    $image = (string)($body['image'] ?? '');

    if ($name === '' || $category === '' || $description === '' || $image === '') {
        respond(422, ['error' => 'Missing required fields.']);
    }

    if (!in_array($status, ['live', 'pending'], true)) {
        $status = 'pending';
    }

    if (!preg_match('/^data:image\/(png|jpe?g|gif|webp);base64,/i', $image)) {
        respond(422, ['error' => 'Invalid image format.']);
    }

    if (strlen($image) > 7_500_000) {
        respond(413, ['error' => 'Image payload too large.']);
    }

    $project = [
        'id' => 'project-' . time() . '-' . bin2hex(random_bytes(3)),
        'name' => $name,
        'category' => $category,
        'description' => $description,
        'link' => $link,
        'status' => $status,
        'image' => $image,
    ];

    $projects = readProjects($dataFile);
    $projects[] = $project;

    if (!writeProjects($dataFile, $projects)) {
        respond(500, ['error' => 'Failed to persist project data.']);
    }

    respond(201, ['project' => $project]);
}

if ($method === 'DELETE') {
    $id = sanitizeString($_GET['id'] ?? '', 120);
    if ($id === '') {
        respond(422, ['error' => 'Project id is required.']);
    }

    $projects = readProjects($dataFile);
    $next = array_values(array_filter($projects, static fn(array $project): bool => ($project['id'] ?? '') !== $id));

    if (count($next) === count($projects)) {
        respond(404, ['error' => 'Project not found.']);
    }

    if (!writeProjects($dataFile, $next)) {
        respond(500, ['error' => 'Failed to persist project data.']);
    }

    respond(200, ['deleted' => true, 'id' => $id]);
}

respond(405, ['error' => 'Method not allowed.']);
